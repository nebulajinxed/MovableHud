package com.github.nebulajinxed.movablehud;

import com.mojang.brigadier.Command;
import net.fabricmc.fabric.api.client.command.v2.ClientCommandManager;
import net.fabricmc.fabric.api.client.command.v2.ClientCommandRegistrationCallback;
import net.minecraft.class_310;
import net.minecraft.class_437;
import com.github.nebulajinxed.movablehud.screen.MovableHudScreen;

import java.util.concurrent.Executors;
import java.util.concurrent.ScheduledExecutorService;
import java.util.concurrent.TimeUnit;

public class Commands {

    public static final ScheduledExecutorService SCHEDULER = Executors.newSingleThreadScheduledExecutor();

    public static void register() {
        ClientCommandRegistrationCallback.EVENT.register(((commandDispatcher, commandRegistryAccess) -> {
            commandDispatcher.register(ClientCommandManager.literal("movableHud")
                    .executes(ctx -> {
                        OpenScreen(new MovableHudScreen());
                        return Command.SINGLE_SUCCESS;
                    })
            );
        }));
    }

    public static void OpenScreen(class_437 screen) {
        SCHEDULER.schedule(() ->
                        class_310.method_1551().execute(() ->
                                class_310.method_1551().method_1507(screen)
                        ),
                50, TimeUnit.MILLISECONDS
        );
    }
}
