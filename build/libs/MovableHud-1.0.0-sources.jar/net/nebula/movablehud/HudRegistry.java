package net.nebula.movablehud;

import net.fabricmc.fabric.api.client.rendering.v1.HudRenderCallback;
import net.fabricmc.fabric.api.client.rendering.v1.hud.HudElementRegistry;
import net.minecraft.class_2960;
import net.minecraft.class_310;
import net.nebula.movablehud.screen.MovableHudScreen;
import org.joml.Matrix3x2fStack;

import java.util.*;

public class HudRegistry {
    private static final List<HudElement> ELEMENTS = new ArrayList<>();
    static class_310 client = class_310.method_1551();

    public static void register(HudElement element, String name) {
        ELEMENTS.add(element);
        HudElementRegistry.addLast(class_2960.method_60655(MovableHudClient.MODID, name), (drawContext, renderTickCounter) -> {
            if (Objects.equals(client.field_1755, new MovableHudScreen())) return;

            Matrix3x2fStack m = drawContext.method_51448();
            m.pushMatrix();
            m.translate(element.getX() - (element.getWidth() / 2), element.getY() - (element.getHeight() / 2));
            m.scale(element.getScale(), element.getScale());
            drawContext.method_51433(class_310.method_1551().field_1772, element.getText(), 0, 0, element.getColor(), element.hasShadow());
            m.popMatrix();
        });
    }

    public static List<HudElement> getByNamespace(String ns) {
        return ELEMENTS.stream()
                .filter(e -> e.getNamespace().equals(ns))
                .toList();
    }

    public static HudElement get(String id) {
        for (HudElement e : HudRegistry.getByNamespace(MovableHudClient.MODID)) {
            if (e.getId().equals(id)) return e;
        }
        return null;
    }
}
