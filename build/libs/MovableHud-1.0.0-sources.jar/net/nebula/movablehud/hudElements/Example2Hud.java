package net.nebula.movablehud.hudElements;

import net.minecraft.class_310;
import net.minecraft.class_332;
import net.nebula.movablehud.HudElement;
import net.nebula.movablehud.MovableHudClient;

public class Example2Hud implements HudElement {
    private int x = 30, y = 50;
    private String text = "Hello HUD test 2";
    private int color = 0xFFFFFFFF;
    private boolean hasShadow = false;
    private String Id = "example2";

    private float scale = 1;

    @Override
    public String getNamespace() { return MovableHudClient.MODID; }

    @Override
    public void render(class_332 ctx, int x, int y, float delta) {
        ctx.method_51433(class_310.method_1551().field_1772, text, x, y, color, hasShadow);
    }

    public int getX() { return x; }
    public int getY() { return y; }
    public String getText() { return text; }
    public int getColor() { return color; }
    public float getHeight() { return class_310.method_1551().field_1772.field_2000 * scale; }
    public float getWidth() { return class_310.method_1551().field_1772.method_1727(text) * scale; }
    public float getScale() { return scale; }
    public boolean hasShadow() { return hasShadow; }
    public String getId() { return this.Id; }

    public void setPosition(int x, int y) { this.x = x; this.y = y; }
    public void setColor(int color) { this.color = color; }
    public void setScale(float scale) { this.scale = scale; }
}
