package net.nebula.movablehud;

import net.minecraft.class_332;

public interface HudElement {
    String getNamespace(); // e.g. "nebula"
    void render(class_332 context, int x, int y, float delta);
    int getX();
    int getY();
    String getText();
    int getColor();
    float getWidth();
    float getHeight();
    float getScale();
    boolean hasShadow();
    String getId();
    void setPosition(int x, int y);
    void setColor(int color);
    void setScale(float scale);
}
